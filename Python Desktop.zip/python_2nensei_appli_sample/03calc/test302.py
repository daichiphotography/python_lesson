a = 1
b = 2
print(f"a={a} b={b}")
print(f"{a}+{b}={a+b}")