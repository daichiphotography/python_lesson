in1 = 18
in2 = 48
txt = f"お母さんが{in2 - in1}歳のとき、あなたを産みましたよ。"
print(txt)
