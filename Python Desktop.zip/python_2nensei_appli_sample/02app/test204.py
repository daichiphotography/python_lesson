import PySimpleGUI as sg
sg.theme_previewer()
